import React from "react";
import { MoreHorizontal } from "lucide-react";

export default function UserProfile() {
  return (
    <div
      className="w-[268px] h-[72px] rounded-[8px] flex items-center justify-between"
      style={{
        paddingTop: 12,
        paddingRight: 12,
        paddingBottom: 16,
        paddingLeft: 12,
      }}
    >
      <div className="w-[184px] h-[44px] flex items-center gap-3">
        <div
          className="w-[44px] h-[44px] rounded-[40px] flex items-center justify-center"
          style={{
            padding: 2,
            border: "0.5px solid rgba(255,255,255,0.25)",
          }}
        >
          <img
            src="/profile.jpg" // replace with your real image path
            alt="User"
            className="w-full h-full rounded-full object-cover"
          />
        </div>

        {/* Name + Email */}
        <div className="w-[128px] h-[41px] flex flex-col gap-[3px] overflow-hidden">
          <div className="text-[14px] leading-[150%] font-semibold text-white truncate">
            Nutan Sai Nandam
          </div>
          <div className="text-[12px] leading-[150%] text-white/60 truncate">
            nutansainandam.com
          </div>
        </div>
      </div>

      {/* More button */}
      <button className="w-[20px] h-[20px] flex items-center justify-center text-white/60 hover:text-white">
        <MoreHorizontal size={18} />
      </button>
    </div>
  );
}
