import React from "react";
import { LayoutGrid, MessageCircle, Video, Image as ImageIcon, Code2 } from "lucide-react";
import NavItem from "./NavItem";
import ChatItem from "./ChatItem";
import UpgradeCard from "./UpgradeCard";
import UserProfile from "./UserProfile";

export default function Sidebar() {
  return (
    <aside className="w-[300px] h-[1080px] p-4 bg-[#0b0b0b] border-r border-white/5">
      {/* Outer layout: gap 20px */}
      <div className="h-full flex flex-col gap-5">
        {/* HEADER: Logo and toggle */}
        <div className="w-[268px] h-[34px] flex items-center justify-between">
          {/* Logo with bracket styling */}
          <div className="flex items-center gap-1">
            <span className="text-[18px] font-light text-white/70">{`{(`}</span>
            <span className="text-[16px] font-semibold tracking-wide text-white">
              codegnan
            </span>
          </div>

          {/* Sidebar toggle button */}
          <button className="w-[32px] h-[32px] rounded-[8px] hover:bg-white/5 flex items-center justify-center text-white/60">
            <LayoutGrid size={18} />
          </button>
        </div>

        {/* MENU SECTION: 268 x 994, justify-between */}
        <div className="w-[268px] h-[994px] flex flex-col justify-between">
          {/* TOP (Hug) */}
          <div className="flex flex-col gap-5">
            {/* General header: 268 x 21 */}
            <div className="w-[268px] h-[21px] flex items-center gap-[10px]">
              <span className="text-[14px] leading-[150%] font-normal text-white/45 capitalize">
                General
              </span>
            </div>

            {/* Menu items block: Hug = EXACT 192 (4 x 48). So gap MUST be 0 */}
            <div className="w-[268px] flex flex-col gap-0">
              <NavItem icon={MessageCircle} label="AI Chat" active radius="rounded-[8px]" />
              <NavItem icon={Video} label="AI Video" />
              <NavItem icon={ImageIcon} label="AI Image" />
              <NavItem icon={Code2} label="AI Development" />
            </div>

            {/* Previous chat menu: 268 x 289, gap 8, border-bottom 0.5 */}
            <div className="w-[268px] h-[289px] flex flex-col gap-2 border-b border-white/10 pb-2">
              {/* Previous chat header: 268 x 21 */}
              <div className="w-[268px] h-[21px] flex items-center gap-[10px]">
                <span className="text-[14px] leading-[150%] font-normal text-white/45">
                  Previous Chat
                </span>
              </div>

              {/* Chat history: Hug = 260, gap 12 => use gap-3 (12px) */}
              <div className="w-[268px] flex flex-col gap-3">
                <ChatItem label="Describe the benefits for a..." />
                <ChatItem label="Generate a list current we..." />
                <ChatItem label="Condense the following se..." />
                <ChatItem label="Describe what post moder..." />
              </div>
            </div>
          </div>

          {/* BOTTOM (NO extra space below upgrade + user) */}
          <div className="flex flex-col gap-5">
            <UpgradeCard />
            <UserProfile />
          </div>
        </div>
      </div>
    </aside>
  );
}
