import React from "react";

export default function NavItem({ icon: Icon, label, active = false, radius = "rounded-[12px]" }) {
  return (
    <button
      className={[
        "w-[268px] h-[48px]",
        "flex items-center justify-between",
        "px-4", // left 16, right 16
        radius,
        "text-[14px] leading-[150%] font-normal",
        active
          ? "border border-white/15 bg-white/5 text-white"
          : "border border-transparent text-white/70 hover:bg-white/5 hover:text-white",
      ].join(" ")}
    >
      <div className="flex items-center gap-3">
        <span className="w-5 h-5 flex items-center justify-center opacity-90">
          <Icon size={18} />
        </span>
        <span className="truncate">{label}</span>
      </div>

      {/* keep justify-between behavior without adding visual elements */}
      <span className="w-0 h-0" />
    </button>
  );
}
