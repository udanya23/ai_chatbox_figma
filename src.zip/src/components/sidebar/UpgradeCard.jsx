import React from "react";
import { Sparkles } from "lucide-react";

export default function UpgradeCard() {
  return (
    <div
      className="w-[268px] h-[131px] rounded-[12px] p-4 flex flex-col justify-between"
      style={{
        background: "linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)",
        border: "1px solid rgba(255, 255, 255, 0.15)",
        boxShadow: "0px 0px 40px 0px rgba(99, 102, 241, 0.35)",
      }}
    >
      {/* Header */}
      <div className="flex items-start gap-3">
        <div className="h-9 w-9 rounded-[10px] bg-white/20 flex items-center justify-center">
          <Sparkles size={18} className="text-white" />
        </div>

        <div className="flex-1">
          <div className="text-[14px] leading-[150%] font-semibold text-white">
            Upgrade Plan
          </div>
          <div className="text-[12px] leading-[150%] text-white/75">
            More access to the best models
          </div>
        </div>
      </div>

      {/* Button - centered text, no arrow */}
      <button
        className="w-full h-[38px] rounded-[8px] flex items-center justify-center text-[13px] font-medium transition-all hover:bg-black/25"
        style={{
          border: "1px solid rgba(255, 255, 255, 0.25)",
          background: "rgba(0, 0, 0, 0.18)",
          color: "#FFFFFF",
        }}
      >
        Upgrade Plan
      </button>
    </div>
  );
}

