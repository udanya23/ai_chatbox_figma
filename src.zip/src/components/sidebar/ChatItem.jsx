import React from "react";
import { MessageSquareText } from "lucide-react";

export default function ChatItem({ label }) {
  return (
    <button
      className={[
        "w-[268px] h-[56px]",
        "flex items-center gap-2",
        "px-4", // 16
        "rounded-[12px] border border-white/10",
        "text-[14px] leading-[150%] font-normal",
        "text-white/65 hover:bg-white/5 hover:text-white/85 transition",
      ].join(" ")}
      title={label}
    >
      <span className="w-5 h-5 flex items-center justify-center opacity-80">
        <MessageSquareText size={18} />
      </span>
      <span className="truncate">{label}</span>
    </button>
  );
}
