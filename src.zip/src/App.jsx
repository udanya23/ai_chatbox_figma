import React from "react";
import Sidebar from "./components/sidebar/Sidebar";
import ScaledStage from "./components/layout/ScaledStage";

export default function App() {
  return (
    <ScaledStage baseWidth={1920} baseHeight={1080}>
      <div className="w-[1920px] h-[1080px] flex bg-[#0b0b0b] overflow-hidden">
        <Sidebar />
        {/* Main content will come next */}
        <div className="flex-1" />
      </div>
    </ScaledStage>
  );
}
