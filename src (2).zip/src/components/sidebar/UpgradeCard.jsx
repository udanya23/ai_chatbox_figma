import React from "react";
import sparklesLogo from "../../assets/sparkles-logo.png";

export default function UpgradeCard() {
  return (
    <div
      className="w-full rounded-[12px] p-4 flex flex-col gap-3"
      style={{
        background: "linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)",
        border: "1px solid rgba(255, 255, 255, 0.15)",
        boxShadow: "0px 0px 30px 0px rgba(99, 102, 241, 0.3)",
      }}
    >
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="h-9 w-9 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0 overflow-hidden">
          <img src={sparklesLogo} alt="" className="w-6 h-6 object-contain" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="text-[14px] leading-[130%] font-semibold text-white">
            Upgrade Plan
          </div>
          <div className="text-[12px] leading-[130%] text-white/75">
            More access to the best models
          </div>
        </div>
      </div>

      {/* Button - White background with black text */}
      <button
        className="w-full h-[36px] rounded-[8px] flex items-center justify-center text-[13px] font-medium transition-all hover:bg-gray-100"
        style={{
          background: "#FFFFFF",
          color: "#000000",
          border: "none",
        }}
      >
        Upgrade Plan
      </button>
    </div>
  );
}
