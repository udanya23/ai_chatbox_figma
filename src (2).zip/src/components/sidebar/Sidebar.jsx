import React from "react";
import { LayoutGrid, MessageCircle, Video, Image as ImageIcon, Code2 } from "lucide-react";
import NavItem from "./NavItem";
import ChatItem from "./ChatItem";
import UpgradeCard from "./UpgradeCard";
import UserProfile from "./UserProfile";
import codegnanLogo from "../../assets/codegnan-logo.png";

export default function Sidebar() {
  return (
    <aside className="w-[300px] h-screen p-4 bg-[#0b0b0b] flex flex-col flex-shrink-0">
      {/* Full height container with space-between */}
      <div className="h-full flex flex-col justify-between overflow-hidden gap-5">
        {/* TOP SECTION - fills available space */}
        <div className="flex flex-col gap-5 flex-1 min-h-0">
          {/* HEADER: Logo and toggle */}
          <div className="w-[268px] h-[34px] flex items-center justify-between">
            {/* Logo from uploaded image */}
            <div className="flex items-center">
              <img
                src={codegnanLogo}
                alt="Codegnan"
                className="h-[24px] object-contain"
              />
            </div>

            {/* Sidebar toggle button */}
            <button className="w-[28px] h-[28px] rounded-[6px] hover:bg-white/5 flex items-center justify-center text-white/50">
              <LayoutGrid size={18} />
            </button>
          </div>

          {/* General Section */}
          <div className="flex flex-col gap-2">
            {/* General header */}
            <span className="text-[12px] leading-[140%] font-normal text-white/55 px-2">
              General
            </span>

            {/* Menu items */}
            <div className="flex flex-col gap-1">
              <NavItem icon={MessageCircle} label="AI Chat" active />
              <NavItem icon={Video} label="AI Video" />
              <NavItem icon={ImageIcon} label="AI Image" />
              <NavItem icon={Code2} label="AI Development" />
            </div>
          </div>

          {/* Previous Chat Section */}
          <div className="flex flex-col gap-2">
            {/* Previous chat header */}
            <span className="text-[12px] leading-[140%] font-normal text-white/55 px-2">
              Previous Chat
            </span>

            {/* Chat history items */}
            <div className="flex flex-col gap-2">
              <ChatItem label="Describe the benefits for a..." />
              <ChatItem label="Generate a list current we..." />
              <ChatItem label="Condense the following se..." />
              <ChatItem label="Describe what post moder..." />
            </div>
          </div>
        </div>

        {/* BOTTOM SECTION - fixed at bottom */}
        <div className="flex flex-col gap-4 flex-shrink-0 mt-auto">
          <UpgradeCard />
          <UserProfile />
        </div>
      </div>
    </aside>
  );
}
