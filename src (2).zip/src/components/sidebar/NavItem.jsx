import React from "react";

export default function NavItem({ icon: Icon, label, active = false }) {
    return (
        <button
            className={[
                "w-full h-[40px]",
                "flex items-center gap-3",
                "px-4",
                "rounded-[8px]",
                "text-[14px] leading-[140%] font-medium",
                "transition-all duration-200",
                active
                    ? "border border-white/15 bg-white/5 text-white"
                    : "border border-transparent text-white/75 hover:bg-white/5 hover:text-white",
            ].join(" ")}
        >
            <span className="w-5 h-5 flex items-center justify-center">
                <Icon size={18} />
            </span>
            <span className="truncate">{label}</span>
        </button>
    );
}
