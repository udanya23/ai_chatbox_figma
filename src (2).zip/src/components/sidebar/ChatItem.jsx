import React from "react";
import { MessageSquareText } from "lucide-react";

export default function ChatItem({ label }) {
    return (
        <button
            className={[
                "w-full h-[44px]",
                "flex items-center gap-3",
                "px-4",
                "rounded-[8px] border border-white/10",
                "text-[13px] leading-[140%] font-normal",
                "text-white/75 hover:bg-white/5 hover:text-white transition-all duration-200",
            ].join(" ")}
            title={label}
        >
            <span className="w-5 h-5 flex items-center justify-center opacity-80">
                <MessageSquareText size={16} />
            </span>
            <span className="truncate">{label}</span>
        </button>
    );
}
