import React from "react";
import iconDocument from "../../assets/icon-document.png";
import iconPresentation from "../../assets/icon-presentation.png";
import iconList from "../../assets/icon-list.png";

const suggestions = [
    {
        icon: iconDocument,
        text: "Help Me To Create A Personal Branding And Web Page",
    },
    {
        icon: iconPresentation,
        text: "Write A Report Based On My Website Data",
    },
    {
        icon: iconList,
        text: "Write A Tailored, Engaging Content, With A Focus Quality",
    },
];

export default function SuggestionCards() {
    return (
        <div className="w-full max-w-[900px] flex items-center justify-center gap-5">
            {suggestions.map((item, index) => (
                <button
                    key={index}
                    className="flex-1 min-w-[260px] max-w-[280px] h-[140px] p-5 rounded-[16px] border border-white/10 
                     hover:bg-white/[0.05] hover:border-white/15 transition-all
                     flex flex-col items-start gap-5 text-left"
                    style={{ backgroundColor: "#3C3C3C" }}
                >
                    <div className="w-[48px] h-[48px] rounded-[12px] flex items-center justify-center overflow-hidden">
                        <img src={item.icon} alt="" className="w-full h-full object-contain" />
                    </div>
                    <span className="text-[14px] leading-[150%] text-white/90 line-clamp-2">
                        {item.text}
                    </span>
                </button>
            ))}
        </div>
    );
}
