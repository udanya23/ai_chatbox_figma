import React from "react";
import { Sparkles, ChevronDown, Plus } from "lucide-react";

export default function Header() {
    return (
        <header className="w-full h-[72px] px-6 py-4 flex items-center justify-end gap-2.5 bg-[#0b0b0b] border-b border-white/10">
            {/* SuperAI 2.0 Dropdown */}
            <button className="h-[30px] px-3 flex items-center gap-1.5 rounded-[6px] bg-white/5 border border-white/10 hover:bg-white/8 transition-all">
                <Sparkles size={13} className="text-purple-400" />
                <span className="text-[11px] font-medium text-white">SuperAI 2.0</span>
                <ChevronDown size={13} className="text-white/50" />
            </button>

            {/* New Chat Button */}
            <button className="h-[30px] px-3 flex items-center gap-1.5 rounded-[6px] bg-white text-black hover:bg-white/90 transition-all">
                <Plus size={13} />
                <span className="text-[11px] font-medium">New Chat</span>
            </button>
        </header>
    );
}
