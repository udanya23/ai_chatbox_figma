import React from "react";
import Header from "./Header";
import Greeting from "./Greeting";
import SuggestionCards from "./SuggestionCards";
import ChatInput from "./ChatInput";

export default function MainContent() {
    return (
        <div className="flex-1 h-full flex flex-col bg-[#1A1A1A] min-w-0">
            {/* Header */}
            <Header />

            {/* Main content area - centered with proper spacing */}
            <div className="flex-1 flex flex-col items-center justify-center gap-10 px-8">
                {/* Greeting section */}
                <Greeting userName="John" />

                {/* Suggestion cards */}
                <SuggestionCards />
            </div>

            {/* Chat input at bottom - no bottom gap */}
            <div className="px-8 pb-6">
                <ChatInput />
            </div>
        </div>
    );
}
