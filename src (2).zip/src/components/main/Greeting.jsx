import React from "react";
import mainOrb from "../../assets/main-orb.png";

export default function Greeting({ userName = "John" }) {
    // Get current hour for greeting
    const hour = new Date().getHours();
    let greeting = "Good Morning";
    if (hour >= 12 && hour < 17) greeting = "Good Afternoon";
    else if (hour >= 17) greeting = "Good Evening";

    return (
        <div className="flex flex-col items-center gap-4">
            {/* Main orb logo */}
            <div className="w-[120px] h-[120px] flex items-center justify-center">
                <img
                    src={mainOrb}
                    alt="AI Assistant"
                    className="w-full h-full object-contain"
                />
            </div>

            {/* Greeting text */}
            <div className="flex flex-col items-center gap-1">
                <span className="text-[14px] text-white/65">{greeting}, {userName}</span>
                <h1 className="text-[28px] font-semibold text-white">
                    How can i assist you today?
                </h1>
            </div>
        </div>
    );
}
