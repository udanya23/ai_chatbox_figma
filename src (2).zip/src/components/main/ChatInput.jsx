import React from "react";
import { Paperclip, Image, ChevronDown } from "lucide-react";
import globeIcon from "../../assets/globe-icon.png";
import sendArrow from "../../assets/send-arrow.png";

export default function ChatInput() {
    return (
        <div className="w-full max-w-[900px] mx-auto flex flex-col">
            {/* Main input container - darker gray #212121 */}
            <div
                className="w-full rounded-[16px] border border-white/10 overflow-hidden"
                style={{ backgroundColor: "#212121" }}
            >
                {/* Text input area with All Web dropdown on the right - increased height */}
                <div className="px-5 py-5 flex items-start justify-between gap-4">
                    <input
                        type="text"
                        placeholder="Ask me anything..."
                        className="flex-1 bg-transparent text-[15px] text-white placeholder:text-white/50 outline-none pt-1"
                    />

                    {/* All Web dropdown - positioned inside input area on the right */}
                    <button className="flex items-center gap-2 px-3 py-1.5 rounded-[8px] bg-[#3C3C3C] hover:bg-[#4a4a4a] transition-colors flex-shrink-0">
                        <img src={globeIcon} alt="" className="w-4 h-4 object-contain" />
                        <span className="text-[13px] text-white">All Web</span>
                        <ChevronDown size={14} className="text-white/60" />
                    </button>
                </div>

                {/* Bottom toolbar */}
                <div className="px-5 py-3 flex items-center justify-between border-t border-white/5">
                    {/* Left side - attachment buttons */}
                    <div className="flex items-center gap-5">
                        <button className="flex items-center gap-2 text-white/55 hover:text-white/75 transition-colors">
                            <Paperclip size={16} />
                            <span className="text-[13px]">Add Attachment</span>
                        </button>
                        <button className="flex items-center gap-2 text-white/55 hover:text-white/75 transition-colors">
                            <Image size={16} />
                            <span className="text-[13px]">Use Image</span>
                        </button>
                    </div>

                    {/* Right side - counter and send */}
                    <div className="flex items-center gap-3">
                        <span className="text-[12px] text-white/50">0/1500</span>

                        {/* Send button with arrow image */}
                        <button className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/15 transition-colors">
                            <img src={sendArrow} alt="Send" className="w-4 h-4 object-contain" />
                        </button>
                    </div>
                </div>
            </div>

            {/* Privacy notice */}
            <p className="mt-4 text-center text-[11px] text-white/50">
                Centra may display inaccurate info, so please double check the response.{" "}
                <a href="#" className="underline hover:text-white/60 transition-colors">
                    Your Privacy & Centra AI
                </a>
            </p>
        </div>
    );
}
