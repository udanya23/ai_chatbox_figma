import React from "react";
import Sidebar from "./components/sidebar/Sidebar";
import MainContent from "./components/main/MainContent";

export default function App() {
  return (
    <div className="w-screen h-screen flex bg-[#0b0b0b] overflow-hidden">
      <Sidebar />
      <MainContent />
    </div>
  );
}


